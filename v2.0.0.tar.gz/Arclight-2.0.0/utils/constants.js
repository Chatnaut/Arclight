module.exports= {
    roles: {
        enterprise: "Enterprise",
        admin: "Admin",
        moderator: "Moderator",
        client: "Client",
    }
}