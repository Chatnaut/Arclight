<footer class="footer">
	<div class="container">
		<hr>
		<p class="text-muted"><a href="https://chatnaut.com" target="_blank">Arclight</a> v2.0.0
	</div>
</footer>