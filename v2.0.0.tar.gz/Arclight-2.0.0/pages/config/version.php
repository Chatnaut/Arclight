<?php header('Location: ../../index.php'); ?>
2.0.0
?>