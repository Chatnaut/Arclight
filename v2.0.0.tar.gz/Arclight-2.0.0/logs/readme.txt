This location is used for web applications to store log information.
