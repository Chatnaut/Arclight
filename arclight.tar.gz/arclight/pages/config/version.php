<?php header('Location: ../../index.php'); ?>
19.01.03
