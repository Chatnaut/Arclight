<footer class="footer">
	    <div class="container">
	    	<hr>
		    <p class="text-muted"><a href="https://chatnaut.com" target="_blank">Chatnaut Cloud</a> v2.0 
	        
	    </div>
</footer>