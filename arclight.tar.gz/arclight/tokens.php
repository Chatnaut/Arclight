<?php header('Location: index.php'); ?>
ow57m5xp78chqhe6kfhupdlx3hdse8mxswtksobgbuj0ya9n8e2qqj0pxh8ll8xwd2bz3z7sw5yomhn5jmiv0vwctwc0trwxl6fl: localhost:5900
